#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <map> 

using namespace std;

void Conver(FILE *fp,FILE* fo) 
{
	char med,last='A';
	int  nw=1;
	while(1)
	{
		med=fgetc(fp);
		while(nw==1){
			if(med<=32)
				med=fgetc(fp);
			else{
				nw=0;
				break;	
			}
		}
		if(med){
			if(med==':'){
				fputc(med,fo);
				last=med; 
			}
			else if(med==';'){
				fputc(med,fo);
				fputc('\n',fo);
				nw=1;
				last=med;
			}
			else if(med<=32){
				if(last==':'){
					last=':';
				}
				else
					last=med;
			}
			else if(med>=33&&med<=126&&med!=':'&&med!=';'){
				if(last==' '|last<=31){
					fputc(' ',fo);
				}
				if(med>='a'&&med<='z'){
					med=med-32;
					fputc(med,fo);
				}
				else fputc(med,fo);
				last=med;
			}
		}
		if(feof(fp))
			break;
	}
}
void ConverTwo(FILE *fm,FILE* fn)
{
	char ned;
	while(1)
	{
		ned=fgetc(fm);
		if(ned>='a'&&ned<='z'){
			ned=ned-32;
			fputc(ned,fn);
		}
		else if(ned==10|ned>=33){
			fputc(ned,fn);
		}
		if(feof(fm))
			break;
	}		
} 		
	
	
int main(int argc, char **argv) 
{
int count = 0;
	int i;
	int a,b,c;
	int B=0;
	FILE *fp,*fm,*fc,*fd,*fo;
	for(i=0;i<argc;i++)
	{
		if(!strcmp(argv[i],"-i"))
		{
			i++;a=i;
		}
		else if(!strcmp(argv[i],"-m"))
		{
			B=1;i++;b=i;
		} 
		else if(!strcmp(argv[i],"-o"))
		{
			i++;c=i;
		}			
	}

	fo=fopen(argv[c],"w+");	
	fp=fopen(argv[a],"r");
	fc=fopen("c.txt","w+");

	Conver(fp,fc);

	fseek(fc,0,0);
	fclose(fp);
	
	if(B) 
	{
		fm=fopen(argv[b],"r");
		fd=fopen("d.txt","w+");	
		ConverTwo(fm,fd);
		fseek(fd,0,0);
		fclose(fm);			
	}

	int R[32]={0};
	R[0]=0;
	int ads=0;
	int value=0;
	map<int,int> memory;
	if(B) { 
		while(!feof(fd)){
			fscanf(fd,"%x:%x\n",&ads,&value);
			memory.insert(map<int,int>::value_type(ads,value));
		}
	} 
	int ii=0;
	int nn=0;
	char ic=fgetc(fc);
	char input[6000000];//map<int,char> input;
	while(1){				
		input[ii]=ic;//input.insert(map<int,char>::value_type(ii,ic));
		ic=fgetc(fc);
		ii++;
		if(feof(fc)) nn=1;
		if(nn==1) break;
	} 

	fclose(fc);
	char buf[4][12];
	int ass[10000]={0};
	int bas[1000] ={0};
	char ba[10000][20]={0};
	char d[20]={0};
	char m;
	int im=0;int in=0;
	int j=0;int k=0;int n=0;
	int e=0;int f=0;int g=0;int h=0;int l=0;int p=0;int q=0;int r=0;int t=0;int s=0;int v=0;
	int sum=0;int num=0;int nw=0;int ne=0;int ew=0;int we=0;int mem=0;int lab=0;int act=0;
	while(1) 
	{
		while(j<4)
		{
			while(k<12)
			{
				//m=fgetc(fc);
				m=input[im];
				im++;
				
				if(!m) n=1;//if(feof(fc)) n=1;
				else if(m==':'){
						bas[s]=im;//bas[s]=ftell(fc);
						for(t=0;t<k;t++)
						{
							ba[s][t]=buf[j][t];
						}
						ba[s][k]='\0';
						s++;	
					k=0;
				}
				else if(m==' '){
					buf[j][k]='\0';
					j++;
					k=0;
				}
				else if(m=='\n') {
					ass[r]=im;//ass[r]=ftell(fc);
					r++;
					r = r % 10000;
				}
				else if(m==';'){
					if(act==1){
						for(v=0;v<s;v++){
							if(!strcmp(ba[v],d)){

								im=bas[v];//fseek(fc,bas[v],0);
								s=v+1;
								act=0;
								lab=0;
								j=4;
								k=12;
								memset(buf, 0, j*k*sizeof(char));
								memset(d, 0, 20*sizeof(char));
							}
						} 
						if(act==1){
							j=4;
							k=12;
							memset(buf, 0, j*k*sizeof(char));
						}
					}
					else{

					if(we){r=r+we-2;
					im=ass[r];//fseek(fc,ass[r],0);
					r++;r=r % 10000;j=4;k=12;we=0;memset(buf, 0, j*k*sizeof(char));}
					else{

					if(ew){j=4;k=12;ew--;memset(buf, 0, j*k*sizeof(char)); }
					else{

					buf[j][k]='\0';
//printf("%d: %s %s %s %s\n", r, buf[0], buf[1], buf[2], buf[3]);
					if(buf[3][0]=='R')  //R型指令 
					{

						if(buf[1][2]=='\0') e=buf[1][1]-'0';else e=10*(buf[1][1]-'0')+(buf[1][2]-'0');
						if(buf[2][2]=='\0') f=buf[2][1]-'0';else f=10*(buf[2][1]-'0')+(buf[2][2]-'0');
						if(buf[3][2]=='\0') g=buf[3][1]-'0';else g=10*(buf[3][1]-'0')+(buf[3][2]-'0');
						if(e==0) R[e]=0;
						else if(!strcmp(buf[0],"ADD")) R[e]=R[f]+R[g];
						else if(!strcmp(buf[0],"SUB")) R[e]=R[f]-R[g];
						else if(!strcmp(buf[0],"AND")) R[e]=R[f]&R[g];
						else if(!strcmp(buf[0],"OR"))R[e]=R[f]|R[g];
						else if(!strcmp(buf[0],"XOR")) R[e]=R[f]^R[g];
						else if(!strcmp(buf[0],"SGT")) if(R[f]>R[g]) R[e]=1;else R[e]=0;
						else if(!strcmp(buf[0],"SEQ")) if(R[f]==R[g]) R[e]=1;else R[e]=0;
						else if(!strcmp(buf[0],"SGE")) if(R[f]>=R[g]) R[e]=1;else R[e]=0;
						else if(!strcmp(buf[0],"SLT")) if(R[f]<R[g]) R[e]=1;else R[e]=0;
						else if(!strcmp(buf[0],"SNE")) if(R[f]!=R[g]) R[e]=1;else R[e]=0;
						else if(!strcmp(buf[0],"SLE")) if(R[f]<=R[g]) R[e]=1;else R[e]=0;
						e=0;f=0;g=0;	
					} 
					else if(buf[3][0]!='R'&&buf[2][0]=='R')//I型指令 
					{

						if(buf[1][2]=='\0') h=buf[1][1]-'0';else h=10*(buf[1][1]-'0')+(buf[1][2]-'0'); 
						if(buf[2][2]=='\0') l=buf[2][1]-'0';else l=10*(buf[2][1]-'0')+(buf[2][2]-'0');
						sum=atoi(buf[3]);
						if(h==0) R[h]=0;
						else if(!strcmp(buf[0],"ADDI")) R[h]=R[l]+sum;	
						else if(!strcmp(buf[0],"SUBI")) R[h]=R[l]-sum;
						else if(!strcmp(buf[0],"ANDI")) R[h]=R[l]&sum;
						else if(!strcmp(buf[0],"ORI")) R[h]=R[l]|sum;
						else if(!strcmp(buf[0],"XORI")) R[h]=R[l]^sum;
						else if(!strcmp(buf[0],"SGTI")) if(R[l]>sum) R[h]=1;else R[h]=0;
						else if(!strcmp(buf[0],"SEQI")) if(R[l]==sum) R[h]=1;else R[h]=0;
						else if(!strcmp(buf[0],"SGEI")) if(R[l]>=sum) R[h]=1;else R[h]=0;
						else if(!strcmp(buf[0],"SLTI")) if(R[l]<sum) R[h]=1;else R[h]=0;
						else if(!strcmp(buf[0],"SNEI"))if(R[l]!=sum) R[h]=1;else R[h]=0;
						else if(!strcmp(buf[0],"SLEI")) if(R[l]<=sum) R[h]=1;else R[h]=0;
						else if(!strcmp(buf[0],"SLLI")) R[h]=(unsigned int)R[l]<<sum;
						else if(!strcmp(buf[0],"SRLI")) R[h]=(unsigned int)R[l]>>sum;
						else if(!strcmp(buf[0],"LB")){
							nw=R[l]+sum;
							R[h]=memory[nw];
						}
						else if(!strcmp(buf[0],"LW")){
							nw=R[l]+sum;
							R[h]=(memory[nw]<<24)+(memory[nw+1]<<16)+(memory[nw+2]<<8)+memory[nw+3];
						}
						if(!strcmp(buf[0],"SB")){
							nw=R[l]+sum;
							memory[nw]=R[h];
						}
						else if(!strcmp(buf[0],"SW")){
							nw=R[l]+sum;
							memory[nw]=R[h]>>24;
							memory[nw+1]=(R[h]>>16)-((R[h]>>24)<<8);
							memory[nw+2]=(R[h]>>8)-((R[h]>>16)<<8);
							memory[nw+3]=R[h]-((R[h]>>8)<<8);
						}
						h=0;l=0;sum=0;nw=0;
					}
					else if(buf[2][0]!='R'&&buf[1][0]=='R'&&buf[2][0]!=0)// op,beqz,bnez指令 
					{
						if(buf[1][2]=='\0') p=buf[1][1]-'0';else p=10*(buf[1][1]-'0')+(buf[1][2]-'0');
						if(buf[2][0]!='-'&&(buf[2][0]<'0'||buf[2][0]>'9')){
							lab=1;
							strcpy(d,buf[2]);
						 
						}
						else {
						num=atoi(buf[2]);

						} 
						if(!strcmp(buf[0],"OP")){
							ne=R[p]+num;
							mem=(memory[ne]<<24)+(memory[ne+1]<<16)+(memory[ne+2]<<8)+memory[ne+3];
							printf("%d\n",mem);
							fprintf(fo,"%d\r\n",mem);
						}
						else if(!strcmp(buf[0],"BEQZ")){

							if(lab==1){
								if(R[p]==0){
									act=1;
								}
							}
							else{
									if(R[p]==0){
										if(num>0) ew=num;
										else if(num<0) we=num+1;
									}	
							}
						}
						else if(!strcmp(buf[0],"BNEZ")){

							if(lab==1){
								if(R[p]!=0){
									act=1;
								}
							}
							else{
									if(R[p]!=0){
										if(num>0) ew=num;
										else if(num<0) we=num+1;
									}
								}
						}
					}
					else if(buf[2][0]!='R'&&buf[1][0]!=0&&buf[2][0]==0)//op,jr指令 
					{
						if(buf[1][0]=='R') {
							if(buf[1][2]=='\0')
								q=buf[1][1]-'0';
							else q=10*(buf[1][1]-'0')+(buf[1][2]-'0');
						}
						else if(buf[1][0]!='-'&&(buf[1][0]<'0'||buf[1][0]>'9')){
							lab=1;

							strcpy(d,buf[1]);
	
						}
							
						if(!strcmp(buf[0],"OP")){
							printf("%d\n",R[q]);
							fprintf(fo,"%d\r\n",R[q]);
						}
						else if(!strcmp(buf[0],"JR")){

							if(lab==1) act=1;
							else{
								if(R[q]>0) ew=R[q]-1;
								else if(R[q]<0) we=R[q];
							}
						}
					}
					else//halt指令 
					{
						;
					}
					j=4;k=12;
					memset(buf, 0, j*k*sizeof(char)); 		
					}
					}
					}
				}
				else {
					buf[j][k]=m;
					k++;
				}
				if(n==1){ break;}
			}
			if(n==1){ break;}
		}
		j=0;
		k=0;
		if(n==1){ break;}
	}	

	if(B) fclose(fd);
	fclose(fo);
	return 0;
} 

																																																																										 		
